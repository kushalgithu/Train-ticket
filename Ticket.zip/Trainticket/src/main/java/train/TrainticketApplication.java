package train;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainticketApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainticketApplication.class, args);
	}

}
